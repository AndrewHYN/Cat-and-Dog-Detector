import os
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image

# Load the model only once (on first request)
model = None

def load_model():
    global model
    if model is None:
        model_path = os.path.join(settings.BASE_DIR, 'dog_cat_model.keras')
        model = tf.keras.models.load_model(model_path)
    return model

def predict_image(img_path):
    model = load_model()
    
    img = image.load_img(img_path, target_size=(224, 224))  # ✅ Fix here
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = img_array / 255.0

    prediction = model.predict(img_array)[0][0]
    
    if prediction > 0.5:
        return 'Dog Detected 🐶'
    else:
        return 'Cat Detected 🐱'

def home(request):
    result = None
    uploaded_image_url = None

    if request.method == 'POST' and request.FILES.get('image'):
        image_file = request.FILES['image']
        fs = FileSystemStorage()
        filename = fs.save(image_file.name, image_file)
        uploaded_image_url = fs.url(filename)

        file_path = os.path.join(settings.MEDIA_ROOT, filename)
        result = predict_image(file_path)

    return render(request, 'detector/home.html', {
        'result': result,
        'uploaded_image_url': uploaded_image_url
    })
