# 🐾 Dog & Cat Detector 🐾

Welcome to the **Dog & Cat Detector** — a web application built with **Django** and powered by a **Convolutional Neural Network (CNN)** to classify images as either a **Dog** or a **Cat**.

---

## 📌 What this project does

This web app allows users to upload an image of a cat or dog, and it predicts whether the image contains a **cat** or **dog** using a deep learning model built with **TensorFlow**.

---

## 🚀 How to run the Django app

1️⃣ **Clone this repository**

```bash
git clone https://github.com/YourUsername/CatDetectDog.git
cd CatDetectDog
